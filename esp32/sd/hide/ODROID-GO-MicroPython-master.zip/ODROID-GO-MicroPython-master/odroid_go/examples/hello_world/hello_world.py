from odroid_go import GO

GO.lcd.set_font(GO.lcd.fonts.TT24)
GO.lcd.set_color(GO.lcd.colors.GREEN, GO.lcd.colors.BLACK)
GO.lcd.print("Hello, ODROID-GO")
