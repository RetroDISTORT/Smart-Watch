from .odroid_go import GO
